using System;
namespace Galaga.GalagaStates {
    public enum GameStateType {
        MainMenu,
        GamePaused,
        GameRunning
    }
}