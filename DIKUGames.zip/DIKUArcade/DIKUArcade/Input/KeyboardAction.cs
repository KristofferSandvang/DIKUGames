namespace DIKUArcade.Input
{
    public enum KeyboardAction
    {
        KeyPress,
        KeyRelease
    }
}
